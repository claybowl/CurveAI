export * from './educationalmaterial.domain.facade'
export * from './educationalmaterial.domain.module'
export * from './educationalmaterial.model'
