export * from './educationalmaterial.application.event'
export * from './educationalmaterial.application.module'
