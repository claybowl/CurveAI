export namespace UsertechnologyupdateApplicationEvent {
  export namespace UsertechnologyupdateCreated {
    export const key =
      'usertechnologyupdate.application.usertechnologyupdate.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
