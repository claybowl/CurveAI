export type AccessControlRoleStatus = 'found' | 'not-found' | 'unknown'
