export type NavigationItem = {
  key: string
  label: string
  onClick: () => void
}
