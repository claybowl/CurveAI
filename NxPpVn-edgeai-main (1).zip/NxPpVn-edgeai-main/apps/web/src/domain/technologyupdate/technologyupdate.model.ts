import { Usertechnologyupdate } from '../usertechnologyupdate'

export class Technologyupdate {
  id: string

  description?: string

  relevance?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  usertechnologyupdatesAsUpdate?: Usertechnologyupdate[]
}
