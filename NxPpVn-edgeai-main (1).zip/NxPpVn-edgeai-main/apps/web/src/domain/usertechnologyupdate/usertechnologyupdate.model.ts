import { User } from '../user'

import { Technologyupdate } from '../technologyupdate'

export class Usertechnologyupdate {
  userId: string

  user?: User

  updateId: string

  update?: Technologyupdate

  id: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
