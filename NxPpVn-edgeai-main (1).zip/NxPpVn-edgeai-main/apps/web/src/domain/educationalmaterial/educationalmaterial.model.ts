export class Educationalmaterial {
  id: string

  title?: string

  content?: string

  linkUrl?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
