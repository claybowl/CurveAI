export * from './educationalmaterial.api'
export * from './educationalmaterial.model'
