export class Serviceprovider {
  id: string

  name?: string

  serviceDescription?: string

  contactInfo?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
